<!DOCTYPE html>


<html>
    <?php require("partials/head.html"); ?>

<body>

    <?php require("partials/nav.html"); ?>

    <!--==================================================================================
    BANNER-MD
    ======================================================================================-->
    <div class="banner-md">
        <div class="banner-bg">
            <div class="banner-color">
                <div class="banner-pattern"></div>
            </div>
        </div>
        <div class="banner-content">
           <div class="line"></div>
            <div class="banner-title">
                <h1>REGISTER</h1>
            </div>
        </div>
    </div>



    <!--==================================================================================
    TEAM LEFT
    ======================================================================================-->
    <section class="register feature">
        <div class="row">
            <div class="col-sm-6">
                <h3>External Delegates</h3>
                <p><i>Registration and/or selection process may vary by university. Contact your university DECA Chapter president for more details. If you are not part of DECA, contact Lilian Verbarg at <a href="mailto:lilian.verbarg@uwdeca.com">lilian.verbarg@uwdeca.com.</a></i></p>
                <p>Fill out the online registration form here by February 20th, 2015:<br><a href="tinyurl.com/Embark-External-Delegate">tinyurl.com/Embark-External-Delegate</a></p>
                <p>Strongly recommended: submit your resume to resume@uwdeca.com by February 23rd, 2015 to have it included in our Résumé Book to be sent to all sponsors and aliates.</p>
            </div>
            <div class="col-sm-6">
                <h3>Internal Delegates</h3>
                <p>Due to limited number of spots available, Waterloo students are responsible for submitted the Internal Delegate Application form by the date listed below. Each delegate must:</p>

                <ol><li>1. Fill out the online application form by Wednesday, February 11th, 2015 @ 11:59 PM at <a href="tinyurl.com/q6fdher">tinyurl.com/q6fdher</a></li>
                <li>2. If selected, you will be notified via email by February 16th, 2015.</li>
                <li>3. Once notified, submit your registration materials and conference fee by February 18th, 2015 @ 11:59 PM. If you do not do so by then we will move to the next person in line on the waiting list. </li>
                <li>Strongly recommended: submit your resume to resume@uwdeca.com by February 23rd, 2015 to have it included in our Résumé Book to be sent to all sponsors and aliates.</li>
                </ol>
            </div>
        </div>

    </section>


    <?php require("partials/footer.html"); ?>

</body>

</html>