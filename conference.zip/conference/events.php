<!DOCTYPE html>


<html>
    <?php require("partials/head.html"); ?>

<body>

    <?php require("partials/nav.html"); ?>

    <!--==================================================================================
    BANNER-MD
    ======================================================================================-->
    <div class="banner-md">
        <div class="banner-bg">
            <div class="banner-color">
                <div class="banner-pattern"></div>
            </div>
        </div>
        <div class="banner-content">
           <div class="line"></div>
            <div class="banner-title">
                <h1>SPEAKERS &amp; WORKSHOPS</h1>
            </div>
        </div>
    </div>


    <!--==================================================================================
    TEAM LEFT
    ======================================================================================-->
    <section class="team" style="min-height:300px;">
        <div class="team-content" style="height:300px;">

            <div class="col-md-3 rodbarr" style="padding:0;">
                <div class="banner-pattern"></div>
            </div>

            <div class="col-md-9 content-us" style="height:300px;">
                <h2>ROD BARR, Former President and CEO of CPA Ontario</h2>

<p>With a career spanning more than 40 years, Rod Barr has held a variety of top leadership
positions and achieved many honours. He spent the majority of his career with Deloitte and Touche LLP, and did stints in Toronto, Hamilton, New York, Vancouver, London and Wilton, Connecticut. From 1996 to 2008, he was the National Securities Partner at Deloitte. From 2004 to 2006, he served as the Chair of the Institute of Chartered Accountants of Ontario (now CPA Ontario). In 2009, he was appointed to the role of President and CEO of the Institute. He retired from that position in 2014. An alumni of the University of Waterloo, he received the Faculty of Arts Alumni Achievement Award in 2007 and a second Alumni Achievement Award from the University of Waterloo’s School of Accounting and Finance in 2014. </p>
            </div>
        </div>
    </section>

        <!--==================================================================================
    FEATURE
    ======================================================================================-->
    <section class="feature">
        <div class="container">
            <div class="row">
                <p>We will be slowly revealing more speakers and workshop hosts during the weeks to come before the conference! Stay tuned and be sure to like us on <a href="http://facebook.com/UWDECA">Facebook</a> and follow us on Twitter (@UW_DECA).</p>
            </div>

        </div>
    </section>

    <?php require("partials/register.html"); ?>

    <?php require("partials/footer.html"); ?>

</body>

</html>