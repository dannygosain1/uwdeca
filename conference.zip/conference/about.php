<!DOCTYPE html>


<html>
    <?php require("partials/head.html"); ?>

<body>

    <?php require("partials/nav.html"); ?>

    <!--==================================================================================
    BANNER-MD
    ======================================================================================-->
    <div class="banner-md">
        <div class="banner-bg">
            <div class="banner-color">
                <div class="banner-pattern"></div>
            </div>
        </div>
        <div class="banner-content">
           <div class="line"></div>
            <div class="banner-title">
                <h1>ABOUT</h1>
            </div>
        </div>
    </div>


    <!--==================================================================================
    FEATURE
    ======================================================================================-->
    <section class="feature">
        <div class="container">
            <div class="row">

                <div class="col-sm-4">
                    <div class="col-md-2"><span class="fa fa-map-marker"></span></div>
                    <div class="col-md-10">
                        <h2>Location.</h2>
                        <p>
                            All events will be taking place at the University of Waterloo, Waterloo Inn Conference Hotel and St. George Banquet Hall.
                        </p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="col-md-2"><span class="fa fa-calendar-o"></span></div>
                    <div class="col-md-10">
                        <h2>Date.</h2>
                        <p>
                            Friday, March 6th and <br/> Sunday, March 8th, 2015
                        </p>
                    </div>
                </div>


                <div class="col-sm-4">
                    <div class="col-md-2"><span class="fa fa-bus"></span></div>
                    <div class="col-md-10">
                        <h2>Transportation.</h2>
                        <p>
                            Delegates are responsible for arranging their own transportation to the University of Waterloo.  Transportation to and from the conference events will be provided for delegates staying at the Waterloo Inn Conference Hotel.
                        </p>
                    </div>
                </div>

            </div>

        </div>
    </section>


    <!--==================================================================================
    TEAM LEFT
    ======================================================================================-->
    <section class="team" style="min-height:400px;">
        <div class="team-content">

            <div class="col-md-6 hongkong" style="padding:0;">
                <div class="banner-pattern"></div>
            </div>

            <div class="col-md-6 content-us">
                <h2>Wider Reach. Broader Horizons.</h2>
                <p>
                    The 2015 Waterloo DECA Conference seeks to inspire individuals to recognize the dissolution of borders due to globalization, and pursue an international career. EMBARK will connect you to those who have established themselves with a global network and show you that having an international career is indeed attainable.
                </p>
                <p>
                    Check out our <a href="">delegate package</a> for more details!
                </p>
            </div>
        </div>
    </section>

        <!--==================================================================================
    FEATURE
    ======================================================================================-->
    <section class="feature">
        <div class="container">
            <div class="row">

                <div class="col-sm-6">
                    <div class="col-md-2"><span class="fa fa-hotel"></span></div>
                    <div class="col-md-10">
                        <h2>Accomodations.</h2>
                        <p>
                            All delegates are welcome to stay at the Waterloo Inn Conference Hotel, located a short five minute drive from the university campus. Delegates are responsible for making their own roommate arrangements.
                            <br/><br/>Waterloo Inn Conference Hotel
                            <br/>475 King Street North
                            <br/>Waterloo ON, N2J 2Z5
                            <br/>(519) 884-0220
                            <br/><a href="http://waterlooinn.com">http://waterlooinn.com</a>
                        </p>
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="col-md-2"><span class="fa fa-institution"></span></div>
                    <div class="col-md-10">
                        <h2>Dress Code.</h2>
                        <p>
                            It is expected that delegates dress in appropriate business formal attire during the events of Friday and Saturday.  This is with the exception of the events on Saturday evening.  This year  Waterloo DECA will be hosting a Gala as a celebration for our 10th Annual Conference, a decade of DECA.  Please bring with you the appropriate semi-formal attire for the event.
                            <br/><br/>Delegates must wear their conference name tags at all times.
                        </p>
                    </div>
                </div>


            </div>

        </div>
    </section>

    <?php require("partials/register.html"); ?>

    <?php require("partials/footer.html"); ?>

</body>

</html>