<!DOCTYPE html>
<html>
    <?php require("partials/head.html"); ?>
<body class="main-page">
    <?php require("partials/nav.html"); ?>

        <div class="banner-lg">
            <div class="banner-bg">
                <div class="banner-color">
                    <div class="banner-pattern"></div>
                </div>
            </div>
            <div class="banner-content">
                <div class="banner-logo"></div>

                <div class="banner-txt">
                    <h3>University of Waterloo DECA's 10th Annual Conference.</h3>
                    <h4 style="margin-top:10px;font-weight:100;">March 6th - March 8th</h4>
                </div>

                <a href="about.php" class="banner-btn">LEARN MORE</a>
                <a href="register.php" class="banner-btn">REGISTER NOW</a>
            </div>
        </div>

        <?php require("partials/footer.html"); ?>
    </div>
</body>
</html>
